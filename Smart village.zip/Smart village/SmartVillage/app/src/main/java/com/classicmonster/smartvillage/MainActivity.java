package com.classicmonster.smartvillage;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {
    CheckBox c1,c2,c3;
    ToggleButton toggle;
    Button save;
    public static String msg="";
    int m=0,l=0,r=0;
    int a[]=new int[3];
    int i=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Context ctx=this;
        c1= (CheckBox) findViewById(R.id.tm);
        c2= (CheckBox) findViewById(R.id.tl);
        c3= (CheckBox) findViewById(R.id.tr);
        save= (Button) findViewById(R.id.done);
        toggle = (ToggleButton) findViewById(R.id.toggle);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    c1.setEnabled(true);
                    c2.setEnabled(true);
                    //c3.setEnabled(true);
                    save.setEnabled(true);
                    BackgroundTask backgroundTask=new BackgroundTask(ctx);
                    backgroundTask.execute("a");
                       if(getSharedPreferences("PREFERENCE", MODE_PRIVATE).getBoolean("m", false)){
                            c1.setChecked(true);
                        }

                        else {
                            c1.setChecked(false);
                        }
                        if(getSharedPreferences("PREFERENCE", MODE_PRIVATE).getBoolean("l", false)){
                            c2.setChecked(true);
                        }
                        else {
                            c2.setChecked(false);
                        }
                        if(getSharedPreferences("PREFERENCE", MODE_PRIVATE).getBoolean("r", false)){
                            c3.setChecked(true);
                        }
                        else {
                            c3.setChecked(false);
                        }

                }
                else {
                    if(getSharedPreferences("PREFERENCE", MODE_PRIVATE).getString("ip", null)!=null) {
                        BackgroundTask backgroundTask = new BackgroundTask(ctx);
                        backgroundTask.execute("m");
                        // The toggle is disabled
                        c1.setEnabled(false);
                        c2.setEnabled(false);
                        c3.setEnabled(false);
                        save.setEnabled(false);
                        c1.setChecked(false);
                        c2.setChecked(false);
                        c3.setChecked(false);
                    }
                }
            }
        });
    }
    public class BackgroundTask extends AsyncTask<String, Void, String> {
        Context ctx;
        String ip=getSharedPreferences("PREFERENCE", MODE_PRIVATE).getString("ip", null);
        AlertDialog alertDialog;
        ProgressDialog pd;
        String result;
        boolean c;
        BackgroundTask(Context ctx) {
            this.ctx = ctx;
        }

        @Override
        protected void onPreExecute() {
            alertDialog = new AlertDialog.Builder(ctx).create();
            pd = new ProgressDialog(ctx);
            pd.setTitle("Loading....");
            pd.setMessage("Please wait..!");
            pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            pd.setCancelable(false);
            pd.show();

        }

        @Override
        protected String doInBackground(String... params) {
            String reg_url = "http://"+ip+"/IoT/mupdates.php";
            if(ip==null) {
                return null;
            }
            else {
                if (params[0] == "a" || params[0] == "m") {
                    String value = params[0];
                    c = true;
                    try {
                        URL url = new URL(reg_url);
                        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                        httpURLConnection.setRequestMethod("POST");
                        httpURLConnection.setDoOutput(true);
                        OutputStream os = httpURLConnection.getOutputStream();
                        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(os));
                        String data = URLEncoder.encode("a", "UTF-8") + "=" + URLEncoder.encode(value, "UTF-8");
                        bufferedWriter.write(data);
                        bufferedWriter.flush();
                        bufferedWriter.close();
                        os.close();
                        InputStream IS = httpURLConnection.getInputStream();
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(IS, "iso-8859-1"));
                        String response = "";
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            response += line;
                        }
                        bufferedReader.close();
                        IS.close();
                        httpURLConnection.disconnect();
                        result = response;
                        return response;
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    c = false;
                    String m = params[0];
                    String l = params[1];
                    String r = params[2];
                    try {
                        URL url = new URL(reg_url);
                        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                        httpURLConnection.setRequestMethod("POST");
                        httpURLConnection.setDoOutput(true);
                        OutputStream os = httpURLConnection.getOutputStream();
                        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(os));
                        String data = URLEncoder.encode("m", "UTF-8") + "=" + URLEncoder.encode(m, "UTF-8") + "&" +
                                URLEncoder.encode("l", "UTF-8") + "=" + URLEncoder.encode(l, "UTF-8") + "&" +
                                URLEncoder.encode("r", "UTF-8") + "=" + URLEncoder.encode(r, "UTF-8");
                        bufferedWriter.write(data);
                        bufferedWriter.flush();
                        bufferedWriter.close();
                        os.close();
                        InputStream IS = httpURLConnection.getInputStream();
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(IS, "iso-8859-1"));
                        String response = "";
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            response += line;
                        }
                        bufferedReader.close();
                        IS.close();
                        httpURLConnection.disconnect();
                        result = response;
                        return response;
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {
            pd.dismiss();
            if(result!=null) {
                m = Integer.parseInt(result.trim().substring(1, 2));
                l = Integer.parseInt(result.trim().substring(3, 4));
                r = Integer.parseInt(result.trim().substring(5, 6));
                if (m == 1) {
                    getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("m", true).commit();
                    c1.setChecked(true);
                } else {
                    getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("m", false).commit();
                    c1.setChecked(false);
                }
                if (l == 1) {
                    getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("l", true).commit();
                    c2.setChecked(true);
                }
                else{
                    getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("l", false).commit();
                    c2.setChecked(false);
                }
                if (r==1) {
                    getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("r", true).commit();
                    c3.setChecked(true);
                }
                else{
                    getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putBoolean("r", false).commit();
                    c3.setChecked(false);
                }

                Toast.makeText(ctx,result,Toast.LENGTH_LONG).show();
            }
            else{
                if(c) {
                    alertDialog.setTitle("status not received!");
                }
                else if(ip==null){
                    alertDialog.setTitle("set IP address! ");
                }
                else{
                    alertDialog.setTitle("Not updated! ");
                }
                alertDialog.setMessage("Try Again!");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {
                        toggle.setChecked(false);
                        c1.setEnabled(false);
                        c2.setEnabled(false);
                        c3.setEnabled(false);
                        c1.setChecked(false);
                        c2.setChecked(false);
                        c3.setChecked(false);
                        save.setEnabled(false);
                    }});

                alertDialog.show();
            }

        }

    }
    public void done(View view) {
        String m, l, r;
        if(c1.isChecked())
            m="1";
        else
            m="0";
        if(c2.isChecked())
            l="1";
        else
            l="0";
        if(c3.isChecked())
            r="1";
        else
            r="0";
        if(getSharedPreferences("PREFERENCE", MODE_PRIVATE).getString("ip", null)!=null) {
            BackgroundTask backgroundTask = new BackgroundTask(this);
            backgroundTask.execute(m, l, r);
        }
        else {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("set IP address! ");
            alertDialog.setMessage("Try Again!");
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int id) {

                }});

            alertDialog.show();
        }
    }
    public void settings(View view){
        if(getSharedPreferences("PREFERENCE", MODE_PRIVATE).getString("ip", null)!=null) {
            Intent intent = new Intent(this, Main2Activity.class);
            startActivity(intent);
        }
        else {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("set IP address! ");
            alertDialog.setMessage("Try Again!");
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int id) {

                }});

            alertDialog.show();
        }
    }
    public void ip(View view){
        EditText ip= (EditText) findViewById(R.id.eip);
        ip.setHint(ip.getText().toString());
        getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putString("ip", ip.getText().toString()).commit();
        Toast.makeText(this,"IP Address set to "+getSharedPreferences("PREFERENCE", MODE_PRIVATE).getString("ip", "no"),Toast.LENGTH_SHORT).show();
    }
    public void readings(View view){
        if(getSharedPreferences("PREFERENCE", MODE_PRIVATE).getString("ip", null)!=null) {
            Intent intent = new Intent(this, Main3Activity.class);
            startActivity(intent);
        }
        else {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("set IP address! ");
            alertDialog.setMessage("Try Again!");
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int id) {

                }});

            alertDialog.show();
        }
    }

}
