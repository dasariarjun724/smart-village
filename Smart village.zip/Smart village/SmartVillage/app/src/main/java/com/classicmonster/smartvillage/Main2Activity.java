package com.classicmonster.smartvillage;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class Main2Activity extends AppCompatActivity {
    EditText es,ewmin, ewmax, ed,eontime,eofftime;
    TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        es = (EditText) findViewById(R.id.sm);
        ewmin = (EditText) findViewById(R.id.wmin);
        ewmax = (EditText) findViewById(R.id.wmax);
        ed = (EditText) findViewById(R.id.d);
        eontime= (EditText) findViewById(R.id.ontime);
        eofftime= (EditText) findViewById(R.id.offtime);
        //getSharedPreferences("PREFERENCE", MODE_PRIVATE).edit().putString("ip", "192.168.0.4").commit();
        //String ip=getSharedPreferences("PREFERENCE", MODE_PRIVATE).getString("ip", "not found!");
        //Toast.makeText(this,ip,Toast.LENGTH_LONG).show();
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

    public void settingsup(View view) {
        String s,wmin, wmax,d,ontime,offtime;
        s=es.getText().toString();
        wmin=ewmin.getText().toString();
        wmax = ewmax.getText().toString();
        d=ed.getText().toString();
        ontime=eontime.getText().toString();
        offtime=eofftime.getText().toString();
        //Toast.makeText(this,s+" "+wmin+" "+wmax+" "+d+" "+ontime+" "+offtime,Toast.LENGTH_SHORT).show();
        BackgroundTask backgroundTask=new BackgroundTask(this);
        backgroundTask.execute(s,wmin,wmax,d,ontime,offtime);
    }
    public class BackgroundTask extends AsyncTask<String,Void,String> {
        Context ctx;
        AlertDialog alertDialog;
        ProgressDialog pd;

        BackgroundTask(Context ctx) {
            this.ctx = ctx;
        }

        @Override
        protected void onPreExecute() {
            alertDialog = new AlertDialog.Builder(ctx).create();
            pd = new ProgressDialog(ctx);
            pd.setTitle("Loading....");
            pd.setMessage("Please wait..!");
            pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            pd.setCancelable(false);
            pd.show();

        }

        @Override
        protected String doInBackground(String... params) {
            String reg_url = "http://"+getSharedPreferences("PREFERENCE", MODE_PRIVATE).getString("ip", null)+"/IoT/adds.php";
            String s = params[0];
            String wmin = params[1];
            String wmax = params[2];
            String d = params[3];
            String ontime = params[4];
            String offtime = params[5];
            try {
                URL url = new URL(reg_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream os = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(os));
                String data = URLEncoder.encode("s", "UTF-8") + "=" + URLEncoder.encode(s, "UTF-8") + "&" +
                        URLEncoder.encode("wmin", "UTF-8") + "=" + URLEncoder.encode(wmin, "UTF-8") + "&" +
                        URLEncoder.encode("wmax", "UTF-8") + "=" + URLEncoder.encode(wmax, "UTF-8") + "&" +
                        URLEncoder.encode("d", "UTF-8") + "=" + URLEncoder.encode(d, "UTF-8") + "&" +
                        URLEncoder.encode("ontime", "UTF-8") + "=" + URLEncoder.encode(ontime, "UTF-8") + "&" +
                        URLEncoder.encode("offtime", "UTF-8") + "=" + URLEncoder.encode(offtime, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                os.close();
                InputStream IS = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(IS, "iso-8859-1"));
                String response = "";
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }
                bufferedReader.close();
                IS.close();
                httpURLConnection.disconnect();
                return response;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {
            pd.dismiss();
            if(result!=null){
                alertDialog.setTitle("Task successful");
                alertDialog.setMessage(result);
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {
                        es.setText("");
                        ewmin.setText("");
                        ewmax.setText("");
                        ed.setText("");
                        eontime.setText("");
                        eofftime.setText("");
                        finish();
                    }});
                alertDialog.show();
            }
            else {
                alertDialog.setTitle("Task Failed");
                alertDialog.setMessage("Try Again");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {
                        es.setText("");
                        ewmin.setText("");
                        ewmax.setText("");
                        ed.setText("");
                        eontime.setText("");
                        eofftime.setText("");
                    }});
                alertDialog.show();}

        }

    }
}