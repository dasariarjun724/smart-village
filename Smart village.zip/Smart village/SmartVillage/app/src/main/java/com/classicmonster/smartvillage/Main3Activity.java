package com.classicmonster.smartvillage;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class Main3Activity extends AppCompatActivity {
    TextView s1,s2,w1,w2,d1,d2,l1,l2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        s1= (TextView) findViewById(R.id.s1);
        s2= (TextView) findViewById(R.id.s2);
        w1= (TextView) findViewById(R.id.w1);
        w2= (TextView) findViewById(R.id.w2);
        d1= (TextView) findViewById(R.id.d1);
        d2=(TextView) findViewById(R.id.d2);
        l1= (TextView) findViewById(R.id.l1);
        l2=(TextView) findViewById(R.id.l2);
        BackgroundTask backgroundTask=new BackgroundTask(this);
        backgroundTask.execute();
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
    public class BackgroundTask extends AsyncTask<String, Void, String> {
        Context ctx;
        AlertDialog alertDialog;
        ProgressDialog pd;

        BackgroundTask(Context ctx) {
            this.ctx = ctx;
        }

        @Override
        protected void onPreExecute() {
            alertDialog = new AlertDialog.Builder(ctx).create();
            pd = new ProgressDialog(ctx);
            pd.setTitle("Loading....");
            pd.setMessage("Please wait..!");
            pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            pd.setCancelable(false);
            pd.show();

        }

        @Override
        protected String doInBackground(String... params) {
            String reg_url = "http://"+getSharedPreferences("PREFERENCE", MODE_PRIVATE).getString("ip", null)+"/IoT/recent.php";
            try {
                URL url = new URL(reg_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream os = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(os));
                /*String data =URLEncoder.encode("username", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8") + "&" +
                        URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                os.close();*/
                InputStream IS = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(IS, "iso-8859-1"));
                String response = "";
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }
                bufferedReader.close();
                IS.close();
                httpURLConnection.disconnect();
                return response;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {
            pd.dismiss();
            if(result!=null){
                String[] value=result.split("&");
                s1.setText(value[0]);
                w1.setText(value[1]);
                d1.setText(value[2]);
                l1.setText(value[3]);
                s2.setText(value[4]);
                w2.setText(value[5]);
                d2.setText(value[6]);
                l2.setText(value[7]);
                Toast.makeText(ctx,"received....",Toast.LENGTH_SHORT).show();
            }
            else{
                int a=10;
                alertDialog.setTitle("Retrive Failed!");
                alertDialog.setMessage("Try Again.....");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE,"OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertDialog.show();
            }
        }
    }
    public void refresh(View view){
        BackgroundTask backgroundTask=new BackgroundTask(this);
        backgroundTask.execute();
    }

}
