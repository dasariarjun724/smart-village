<?php
require"init.php";
$s=$_POST["s"];
$wmin=$_POST["wmin"];
$wmax=$_POST["wmax"];
$d=$_POST["d"];
$ontime=$_POST['ontime'];
$offtime=$_POST['offtime'];
$sql_query="update settings set s='$s',wmin='$wmin',wmax='$wmax',d='$d',ontime='$ontime',offtime='$offtime'";
$result=mysqli_query($con,$sql_query);
if($result)
{
	echo "Setting updated!";
}
else
	echo "problem0";
//header("Location: add1.php");
?>
 
