<?php
	include 'init.php';
	
	if(isset($_GET['a']) || isset($_POST['a']))
	{
		if($_POST['a']== "a")
		{
			$result2 = mysqli_query($con, "UPDATE settings set mobile='1'");	
		}
		else if($_POST['a'] == "m")
		{
			$result2 = mysqli_query($con, "UPDATE settings set mobile='0'");
		}
		$result = mysqli_query($con, "SELECT * FROM status WHERE mode = 'automatic'");
		if($result && $result2)
		{
			$row = mysqli_fetch_assoc($result);
			echo "&".$row['m']."&".$row['l']."&".$row['r']."&";
		}
		
		//$result_m = mysqli_query($con, "SELECT mobile FROM settings");
		//$row = mysqli_fetch_assoc($result_m);
		//if($row['mobile'] == 1)
		//{
			
		//}
	}
	else
	{
		$m = $_POST['m'];
		$l = $_POST['l'];
		$r = $_POST['r'];	
		$sql_updates = "UPDATE status set  r='$r',m='$m',l='$l' WHERE mode = 'mobile';";
		$result = mysqli_query($con, $sql_updates);
		
		if($result)
		{
			echo "&".$m."&".$l."&".$r."&";
		}
		else
		{
			echo "";
		}
	}
	
?>