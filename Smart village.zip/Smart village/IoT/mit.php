<?php
include 'init.php';
$result = mysqli_query($con,"SELECT m FROM status WHERE mode = 'mobile'");
if($result)
{
	$row = mysqli_fetch_assoc($result);
	echo $row['m'];
}



?>