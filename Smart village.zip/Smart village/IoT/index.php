<!DOCTYPE html>
<html>
<head>
<title>Home</title>
</head>

<body>

<!--right-->
<div id="body">
<div id="left">

<br /><br />
<P ><B><h3>Progress</h3></FONT></B></P>

</div></div>
<?php
      $username = "root";
      $password = "";
      $host = "localhost";

      $connector = mysqli_connect($host,$username,$password,"iot")
          or die("Unable to connect");
        echo "Connections are made successfully::";
    

      //execute the SQL query and return records
      $result = mysqli_query($connector,"SELECT * FROM sample");
      ?>
<table>
      <!--<thead>
        <tr>
          <th>sensor Value</th>
        </tr>
      </thead>   -->
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc( $result ) ){
            //echo "$row";
            echo
            "<tr>
              <td>".$row['s']."</td>
			  <td>".$row['w']."</td>
			  <td>".$row['d']."</td>
            </tr>";
          }
        ?>
      </tbody>
    </table>
     <?php mysqli_close($connector); ?>
<br/><br/>

</body>
</html>
