<?php

	date_default_timezone_set('Asia/Kolkata');
	session_start();
	require"init.php";
	
	$r = 0;
	$motor = 0;
	$sql_query1="select * from settings";
	$result=mysqli_query($con,$sql_query1);
	$count=mysqli_num_rows($result);
	if($count==1)
	{
		$row=mysqli_fetch_assoc($result);
		$smax=$row["s"];
		$wmin=$row["wmin"];
		$wmax=$row["wmax"];
		$dr=$row["d"];	
		$ontime = $row['ontime'];
		$offtime = $row['offtime'];
		$mobile = $row['mobile'];	
		$starttime = date('y-m-d '.$ontime.':s');
		$endtime = date('y-m-d '.$offtime.':s');
	//echo "&".$smin."&".$smax."&".$wmin."&".$wmax."& ".$dr."&$";
	}
	if($mobile == 1)
	{
			
		$result = mysqli_query($con, "SELECT * FROM status WHERE mode = 'mobile'");
		if($result)
		{
			$row = mysqli_fetch_assoc($result);
			$motor = $row['m'];
			$l = $row['l'];
			$r = $row['r'];
		}
			
			
	}
	if($mobile == 0)
	{
		$result2 = mysqli_num_rows(mysqli_query($con, "SELECT * FROM sample"));
		$result2 = $result2 - 1;
		$result1 = mysqli_query($con,"SELECT * FROM sample LIMIT $result2,1");
		if($result1)
		{
			while($row = mysqli_fetch_array($result1))
			{//echo $row['s']." ".$row['w']." ".$row['d']." ".$row['p'];
				$soil = $row['s'];
				$water = $row['w'];
				$density = $row['d'];
				$p_status = $row['p'];
				$light = $row['l'];
			}
			if($offtime < $ontime)
			{
				$endtime = date('y-m-d H:i:s',strtotime($endtime.'+1 day'));
			}
			if((date('y-m-d H:i:s') < $endtime && date('y-m-d H:i:s') > $starttime) || (date('y-m-d H:i:s') < $endtime && date('y-m-d H:i:s') > $starttime))
				$l = 1;
			else
				$l = 0;
			if($p_status == 1)
			{
				if($soil <= $smax && $water <= $wmax && $water > $wmin)
				{
					$motor = 0;
					$_SESSION['motor_status'] = "off";
				}
				else if($water >= $wmax)
				{
					$motor = 0;
					$_SESSION['motor_status'] = "off";
				}
				else if($soil >= $smax ||  $water < $wmin)
				{
					$motor = 1;
					$_SESSION['motor_status'] = "on";
				}
						
			}
			if($p_status == 0)
			{
					$motor = 0;
					$_SESSION['motor_status'] = "off";
			}
			
		}
		$result = mysqli_query($con, "UPDATE status SET m= '$motor', l= '$l',r='$r'");
	}
	echo "&".$motor."&".$l."&0&";
?>