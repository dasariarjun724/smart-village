<?php
require"init.php";
$s=$_GET["s"];
$w=$_GET["w"];
$d=$_GET["d"];
$p=$_GET["p"];
$l=$_GET['l'];
$rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM sample"));
$rows = $rows+1;
$sql_query="insert into sample values('$rows','$s','$w','$d','$p','$l')";
$result=mysqli_query($con,$sql_query);
if($result)
{

$smax="";
$wmin="";
$wmax="";
$dr="";
	$sql_query1="select * from settings";
	$result=mysqli_query($con,$sql_query1);
	$count=mysqli_num_rows($result);
	if($count==1)
	{
		$row=mysqli_fetch_assoc($result);
		
		$smax=$row["s"];
		$wmin=$row["wmin"];
		$wmax=$row["wmax"];
		$dr=$row["d"];
		
		echo "&".$smax."&".$wmin."&".$wmax."& ".$dr."&$";
		//echo "&".$smin."&".$smax."&".$wmin."&".$wmax."&".$dr;			
	}
	//echo "&".$s."&".$w."&".$d;
}
else
	echo "problem0";
//header("Location: add1.php");
?>
 
