<?php
	include 'init.php';
	$array = array();
	$result2 = mysqli_num_rows(mysqli_query($con, "SELECT * FROM sample"));
	$result2 = $result2 - 2;
	$result1 = mysqli_query($con,"SELECT * FROM sample LIMIT $result2,2");
	if($result1)
	{
		while($row = mysqli_fetch_array($result1))
		{
			$array[] = $row['s'];
			$array[] = $row['w'];
			$array[] = $row['d'];
			$array[] = $row['l'];
		}
		echo $array[0]."&".$array[1]."&".$array[2]."&".$array[3]."&".$array[4]."&".$array[5]."&".$array[6]."&".$array[7];
	}
?>